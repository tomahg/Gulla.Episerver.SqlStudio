define(
"dojo/cldr/nls/ko/currency", //begin v1.x content
{
	"HKD_displayName": "홍콩 달러",
	"CHF_displayName": "스위스 프랑",
	"CAD_displayName": "캐나다 달러",
	"CNY_displayName": "중국 위안 인민폐",
	"AUD_displayName": "호주 달러",
	"JPY_displayName": "일본 엔화",
	"USD_displayName": "미국 달러",
	"GBP_displayName": "영국령 파운드 스털링",
	"AUD_symbol": "AU$",
	"EUR_displayName": "유로화"
}
//end v1.x content
);